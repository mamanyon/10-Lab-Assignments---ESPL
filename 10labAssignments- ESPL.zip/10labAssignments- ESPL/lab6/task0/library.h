#ifndef LAB6_LIBRARY_H
#define LAB6_LIBRARY_H

void hello(void);

#endif //LAB6_LIBRARY_H
